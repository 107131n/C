//#include<stdio.h>
//
//int main()
//{
//	int i = 1;
//	int a = 0;
//
//	printf("��ȸ�� �������� �Է��ϼ���:");
//	scanf_s("%d", &a);
//
//	while (i < 10);
//	{
//		printf("%d * %d = %d\n", a ,i ,(a * i));
//		i++;
//	}
//	return 0;
//}

//#include <stdio.h>
//void main()
//{
//	int i;
//	for (i = 0; i < 10; i++)
//	{
//		printf("Hello World\n");
//	}
//	return;
//}